#!/data/data/com.termux/files/usr/bin/bash
echo "==== HACKER MENU ===="
echo "1) Nmap Recon"
echo "2) Hydra Brute"
echo "3) Routersploit"
echo "4) WiFi Info"
read -p "Choose: " opt

case $opt in
  1) bash termux-nmap-auto.sh ;;
  2) bash termux-hydra-http.sh ;;
  3) bash routersploit-auto.sh ;;
  4) bash wifi-info.sh ;;
  *) echo "Invalid." ;;
esac
