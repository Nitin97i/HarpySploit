#!/data/data/com.termux/files/usr/bin/bash
termux-wifi-connectioninfo | jq .
