#!/data/data/com.termux/files/usr/bin/bash
read -p "📶 Enter IP/subnet (e.g. 192.168.1.0/24): " subnet
echo "[*] Scanning..."
nmap -A -T4 $subnet > nmap_result.txt
echo "[✅] Scan complete. Results saved to nmap_result.txt"
