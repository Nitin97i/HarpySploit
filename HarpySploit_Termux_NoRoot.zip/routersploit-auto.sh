#!/data/data/com.termux/files/usr/bin/bash
cd routersploit || git clone https://github.com/threat9/routersploit && cd routersploit
pip install -r requirements.txt
python3 rsf.py
